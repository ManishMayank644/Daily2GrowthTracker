# Daily 2% Growth Tracker — Android project

This is an Android Studio project that wraps the supplied HTML tracker in an offline WebView app.

## Included
- Preserves the supplied tracker layout and calculations.
- Works offline; the HTML is bundled in `app/src/main/assets/index.html`.
- WebView DOM storage is enabled so the existing `localStorage` data persists between launches.
- Adds **Backup Data** and **Restore Data** in the Setup menu.
- Backup/restore uses a JSON file through Android's system file picker.
- CSV export uses Android's Save As dialog.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder (`Daily2GrowthTracker`) in Android Studio.
3. Allow Gradle sync to finish. Use JDK 17 if Android Studio asks.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
7. Transfer the APK to your phone and install it. You may need to allow installation from that file manager.

## Data safety
- Tracker data stays on the device in the app's WebView storage; no account or internet connection is used.
- Use **Setup → Backup Data** regularly and keep the JSON backup somewhere safe.
- **Restore Data** replaces the current tracker data with the selected backup.
- Clearing the app's storage or uninstalling the app can erase locally stored tracker data. Back it up first.

## Package details
- Application ID: `com.manish.dailygrowth`
- Minimum Android version: Android 6.0 (API 23)
- Target SDK: 35
- Version: 1.0

The project source is provided; an APK has not been compiled or signed in this environment.
