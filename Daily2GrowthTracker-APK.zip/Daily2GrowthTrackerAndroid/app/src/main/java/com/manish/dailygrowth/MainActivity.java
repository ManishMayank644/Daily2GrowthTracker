
    package com.manish.dailygrowth;

    import android.app.Activity;
    import android.content.Intent;
    import android.net.Uri;
    import android.os.Bundle;
    import android.util.Base64;
    import android.webkit.JavascriptInterface;
    import android.webkit.WebChromeClient;
    import android.webkit.WebSettings;
    import android.webkit.WebView;
    import android.webkit.WebViewClient;
    import android.widget.Toast;

    import org.json.JSONObject;

    import java.io.ByteArrayOutputStream;
    import java.io.InputStream;

    public class MainActivity extends Activity {
        private WebView webView;
        private byte[] pendingSaveBytes;
        private String pendingMime = "application/octet-stream";
        private String pendingFilename = "tracker-backup.json";
        private static final int CREATE_FILE = 101;
        private static final int OPEN_FILE = 102;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            getWindow().setStatusBarColor(android.graphics.Color.rgb(7, 11, 24));
            getWindow().setNavigationBarColor(android.graphics.Color.rgb(7, 11, 24));

            webView = new WebView(this);
            setContentView(webView);

            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true); // Keeps tracker data between app launches.
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setDatabaseEnabled(true);

            webView.setWebViewClient(new WebViewClient());
            webView.setWebChromeClient(new WebChromeClient());
            webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
            webView.loadUrl("file:///android_asset/index.html");
        }

        private class AndroidBridge {
            @JavascriptInterface
            public void saveTextFile(String filename, String mime, String base64) {
                try {
                    pendingFilename = filename;
                    pendingMime = mime;
                    pendingSaveBytes = Base64.decode(base64, Base64.DEFAULT);
                    runOnUiThread(() -> {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType(pendingMime);
                        intent.putExtra(Intent.EXTRA_TITLE, pendingFilename);
                        startActivityForResult(intent, CREATE_FILE);
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Could not prepare the file.", Toast.LENGTH_LONG).show());
                }
            }

            @JavascriptInterface
            public void chooseBackupFile() {
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, OPEN_FILE);
                });
            }
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
            Uri uri = data.getData();

            if (requestCode == CREATE_FILE && pendingSaveBytes != null) {
                try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) out.write(pendingSaveBytes);
                    Toast.makeText(this, "File saved.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Unable to save file.", Toast.LENGTH_LONG).show();
                } finally {
                    pendingSaveBytes = null;
                }
            } else if (requestCode == OPEN_FILE) {
                try (InputStream in = getContentResolver().openInputStream(uri);
                     ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                    String json = new String(out.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
                    webView.evaluateJavascript("window.restoreFromNative(" +
                            JSONObject.quote(json) + ")", null);
                } catch (Exception e) {
                    Toast.makeText(this, "Unable to read backup file.", Toast.LENGTH_LONG).show();
                }
            }
        }

        @Override
        public void onBackPressed() {
            if (webView != null && webView.canGoBack()) webView.goBack();
            else super.onBackPressed();
        }
    }
